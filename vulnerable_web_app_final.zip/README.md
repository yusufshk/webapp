# Vulnerable Web App

This is a vulnerable web application built with Flask for learning purposes.

## Features

- User registration and login
- Profile page
- Change password
- Image upload and gallery
- Create and view posts

## How to Run

1. Install Flask:
   ```bash
   pip install flask
   ```

2. Run the application:
   ```bash
   python app.py
   ```

3. Open your browser and go to:
   ```
   http://127.0.0.1:5000/
   ```

> ⚠️ This application is intentionally vulnerable. Do not deploy it in production environments.